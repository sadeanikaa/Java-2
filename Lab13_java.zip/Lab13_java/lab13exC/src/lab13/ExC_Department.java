package lab13;

import java.util.List;

public class ExC_Department {
    private String code;
    private String name;
    private List<ExC_Module> modules;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ExC_Module> getModules() {
        return modules;
    }

    public void setModules(List<ExC_Module> modules) {
        this.modules = modules;
    }

    @Override
    public String toString() {
        return "ExC_Department [code=" + code + ", name=" + name + ", modules=" + modules + "]";
    }

}