package lab13;

public class ExC_Module {
    private int credits;
    private String code;
    private String title;

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "ExC_Module [credits=" + credits + ", code=" + code + ", title=" + title + "]";
    }

}
