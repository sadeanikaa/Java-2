package lab13;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        ExC_Module e1 = new ExC_Module();
        e1.setCode("CO2102");
        e1.setTitle("Databases and Domain Modelling");
        e1.setCredits(10);

        ExC_Module e2 = new ExC_Module();
        e2.setCode("CO2103");
        e2.setTitle("Software Engineering");
        e2.setCredits(30);

        ExC_Department d1 = new ExC_Department();
        d1.setCode("INF");
        d1.setName("Informatics");
        d1.setModules(new ArrayList<>());
        d1.getModules().add(e1);
        d1.getModules().add(e2);


        ExC_Department d2 = new ExC_Department();
        d2.setCode("ENG");
        d2.setName("Engineering");

        System.out.println(d1);
        System.out.println(d2);

    }

}