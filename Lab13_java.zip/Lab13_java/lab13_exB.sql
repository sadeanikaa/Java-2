DROP TABLE IF EXISTS ExB_Employee, ExB_Department;

CREATE TABLE ExB_Employee (
    id int,
    name VARCHAR(20),
    job_title VARCHAR(20),
    PRIMARY KEY (id)
);


CREATE TABLE ExB_Department (
    code VARCHAR(3),
    name VARCHAR(20),
    dept_hod int,
    FOREIGN KEY (dept_hod) REFERENCES ExB_Employee(id),
    PRIMARY KEY (code)
); 

INSERT INTO ExB_Employee VALUES 
(1, "Lu Liu", "Professor"),
(2, "Richard Feynman", "Professor");

INSERT INTO ExB_Department VALUES 
("INF", "Informatics", 1),
("ENG", "Engineering", 2);