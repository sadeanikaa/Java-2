package lab13;

public class ExB_Employee {
    private int id;
    private String name;
    private String job_title;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return job_title;
    }

    public void setTitle(String title) {
        this.job_title = title;
    }

    @Override
    public String toString() {
        return "ExB_Employee [id=" + id + ", name=" + name + ", title=" + job_title + "]";
    }

}

