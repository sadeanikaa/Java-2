package lab13;

public class Main {

    public static void main(String[] args) {

        ExB_Employee e1 = new ExB_Employee();
        e1.setId(1);
        e1.setName("Lu Liu");
        e1.setTitle("Professor");

        ExB_Employee e2 = new ExB_Employee();
        e2.setId(2);
        e2.setName("Richard Feynman");
        e2.setTitle("Professor");

        ExB_Department d1 = new ExB_Department();
        d1.setCode("INF");
        d1.setName("Informatics");
        d1.setHod(e1);


        ExB_Department d2 = new ExB_Department();
        d2.setCode("ENG");
        d2.setName("Engineering");
        d2.setHod(e2);

        System.out.println(d1);
        System.out.println(d2);

    }

}
