package lab13;

public class ExB_Department {
    private String code;
    private String name;
    private ExB_Employee dept_hod;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ExB_Employee getHod() {
        return dept_hod;
    }

    public void setHod(ExB_Employee dept_hod) {
        this.dept_hod = dept_hod;
    }

    @Override
    public String toString() {
        return "ExA_Department [code=" + code + ", name=" + name + ", hod=" + dept_hod + "]";
    }

}

