DROP TABLE IF EXISTS ExC_Department, ExC_Module;

CREATE TABLE ExC_Department (
    code VARCHAR(3),
    name VARCHAR(20),
    PRIMARY KEY (code)
); 

CREATE TABLE ExC_Module (
    code VARCHAR(6),
    title VARCHAR(200),
    credits int,
    dept VARCHAR(3),
    PRIMARY KEY (code),
    FOREIGN KEY (dept) REFERENCES ExC_Department(code)
); 

INSERT INTO ExC_Department VALUES 
("INF", "Informatics"),
("ENG", "Engineering");

INSERT INTO ExC_Module VALUES 
("CO2102", "Databases and Domain Modelling", 10, "INF"),
("CO2103", "Software Engineering", 30, "INF");