DROP TABLE IF EXISTS ExD_DepartmentEmployee, ExD_Employee, ExD_Department;

CREATE TABLE ExD_Employee (
    id int,
    name VARCHAR(20),
    job_title VARCHAR(20),
    PRIMARY KEY (id)
);


CREATE TABLE ExD_Department (
    code VARCHAR(3),
    name VARCHAR(20),
    PRIMARY KEY (code)
); 

CREATE TABLE ExD_DepartmentEmployee (
    dept_code VARCHAR(3),
    employee_id int,
    FOREIGN KEY (dept_code) REFERENCES ExD_Department(code),
    FOREIGN KEY (employee_id) REFERENCES ExD_Employee(id)
); 
INSERT INTO ExD_Employee VALUES 
(1, "Lu Liu", "Professor"),
(2, "Victoria Wright", "Teaching Fellow");

INSERT INTO ExD_Department VALUES 
("INF", "Informatics"),
("ENG", "Engineering");

INSERT INTO ExD_DepartmentEmployee VALUES
("INF", 1),
("ENG", 1),
("INF", 2);