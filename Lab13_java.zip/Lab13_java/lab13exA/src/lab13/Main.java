package lab13;

public class Main {

    public static void main(String[] args) {
        ExA_Department d1 = new ExA_Department();
        d1.setCode("INF");
        d1.setName("Informatics");

        System.out.println(d1);

        d1 = new ExA_Department();
        d1.setCode("ENG");
        d1.setName("Engineering");

        System.out.println(d1);

        d1 = new ExA_Department();
        d1.setCode("PHY");
        d1.setName("Physics");

        System.out.println(d1);
    }

}
