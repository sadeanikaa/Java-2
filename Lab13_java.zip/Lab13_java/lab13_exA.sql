DROP TABLE IF EXISTS ExA_Department;

CREATE TABLE ExA_Department (
    code VARCHAR(3),
    name VARCHAR(20),
    PRIMARY KEY (code)
); 

INSERT INTO ExA_Department VALUES 
("INF", "Informatics"),
("ENG", "Engineering"),
("PHY", "Physics");

SELECT * FROM ExA_department;