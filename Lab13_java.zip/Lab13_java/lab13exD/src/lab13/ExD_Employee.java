package lab13;

import java.util.ArrayList;
import java.util.List;

public class ExD_Employee {
    private int id;
    private String name;
    private String job_title;
    private List<ExD_Department> departments = new ArrayList<>();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return job_title;
    }

    public void setTitle(String title) {
        this.job_title = title;
    }

    public List<ExD_Department> getDepartments() {
        return departments;
    }

    public void setDepartments(List<ExD_Department> departments) {
        this.departments = departments;
    }

    @Override
    public String toString() {
        return "ExD_Employee [id=" + id + ", name=" + name + ", job_title=" + job_title + "]";
    }

}
