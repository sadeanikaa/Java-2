package lab13;

public class Main {

    public static void main(String[] args) {

        ExD_Employee e1 = new ExD_Employee();
        e1.setId(1);
        e1.setName("Lu Liu");
        e1.setTitle("Professor");


        ExD_Employee e2 = new ExD_Employee();
        e2.setId(2);
        e2.setName("Victoria Wright");
        e2.setTitle("Teaching Fellow");

        ExD_Department d1 = new ExD_Department();
        d1.setCode("INF");
        d1.setName("Informatics");


        ExD_Department d2 = new ExD_Department();
        d2.setCode("ENG");
        d2.setName("Engineering");

        e1.getDepartments().add(d1);
        d1.getEmployees().add(e1);

        e2.getDepartments().add(d1);
        d1.getEmployees().add(e2);

        e1.getDepartments().add(d2);
        d2.getEmployees().add(e1);


        System.out.println(d1);
        System.out.println(d2);

    }

}
