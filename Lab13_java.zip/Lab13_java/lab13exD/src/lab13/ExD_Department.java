package lab13;

import java.util.ArrayList;
import java.util.List;

public class ExD_Department {
    private String code;
    private String name;
    private List<ExD_Employee> employees = new ArrayList<>();

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ExD_Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<ExD_Employee> employees) {
        this.employees = employees;
    }

    @Override
    public String toString() {
        return "ExD_Department [code=" + code + ", name=" + name + ", employees=" + employees + "]";
    }

}
